# 第1次作業-作業-HW1
>
>學號：111104105
><br />
>姓名：陳郁升
><br />
>作業撰寫時間：20 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2024/03/23
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x] 說明內容
- [x] 個人認為完成作業須具備觀念

## 說明程式與內容
1. fork並clone到自己的倉庫  
2. 新增A.txt 輸入「This is an apple.」  
3. add,commit,push到倉庫  
4. 打開A.txt 在apple後插入五列「This is a bear.」  
5. add,commit,push到倉庫  
6. 在apple後插入五列「This is a cake.」，並將第一列的apple刪除  
7. add,commit,push到倉庫   
8. 找到f步驟時commit的編號，並用git check out回到f步驟  
9. 新增分支dev，並切換到dev分支  
10. 在dev分支把A.txt內的bear刪掉，只留一列apple  
11. 切回main  
12. 合併分支並add,commit,push到倉庫  
  
git graph線圖  
![Alt text](answer.png)   
1.開啟亞東醫院掛號系統  
![Alt text](./femh/1.png)  
2.選擇要掛的科  
![Alt text](./femh/1.5.png)  
3.選擇日期和醫師  
![Alt text](./femh/2.png)  
4.複診輸入個人資料  
![Alt text](./femh/3.png)  
5.掛號成功  
![Alt text](./femh/4.png)  
6.取消掛號  
![Alt text](./femh/5.png)  
![Alt text](./femh/6.png)  
## 個人認為完成作業須具備觀念
這次的作業跟上學期的網頁很像，都在學習git的使用，不過這次有多一個分支處理衝突，算是進階的部份。掛號可以讓我們知道在一個系統處理流程的重要性，以及在網頁上怎麼讓使用者清楚的操作。 
